//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifndef __TEMPLATES_H
#define __TEMPLATES_H

// Template function for equality comparison through pointer through pointer
template<class T>
bool eq(const T* the, const T* that) {
  return *the == *that;
}

// Template function for non-equality comparision through pointer through pointer
template<class T>
bool neq(const T* the, const T* that) {
  return *the != *that;
}

// Template function for greater-than inequality comparison through pointer through pointer
template<class T>
bool gt(const T* the, const T* that) {
  return *the > *that;
}

// Template function for less-than inequality comparison through pointer through pointer
template<class T>
bool lt(const T* the, const T* that) {
  return *the < *that;
}

// Template function for greater-than-or-equal-to comparison through pointer
template<class T>
bool ge(const T* the, const T* that) {
  return *the >= *that;
}

// Template function for lesser-than-or-equal-to comparison through pointer
template<class T>
bool le(const T* the, const T* that) {
  return *the <= *that;
}


// Support functions (Boost extension).
// Called repeatedly to incrementally create a hash value from several variables.
template <class T>
inline void hash_combine(std::size_t& seed, T const& v) {
	std::hash<T> hasher;
    seed ^= hasher(v) + 0x9e3779b9 + (seed<<6) + (seed>>2);
}

#endif // __TEMPLATES_H
