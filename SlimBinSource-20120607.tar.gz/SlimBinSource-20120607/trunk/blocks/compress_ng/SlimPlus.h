//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifndef __SLIMPLUS_H
#define __SLIMPLUS_H

#include <queue>
#include <unordered_map>

#include "Algo_ng.h"

class SlimPlus: public Algo_ng {

// SlimPlus

public:

	SlimPlus(CodeTable* ct, HashPolicyType hashPolicy, Config* config);
	~SlimPlus();

	virtual string	GetShortName();

	virtual CodeTable*	DoeJeDing(const uint64 candidateOffset=0, const uint32 startSup=0);

	void UpdateCandidates();

private:

	static bool compareCandidates(const ItemSet* a, const ItemSet* b);

	enum ScoreItemSetType { EXACT, SUPPORT_DB, SUPPORT_CS};
	ScoreItemSetType mScoreItemSetType;
	double ScoreItemSet(const ItemSet* is);

	typedef unordered_map<const ItemSet*, double> CandidatesScores;
	static CandidatesScores mCandidatesScores;

	typedef priority_queue<const ItemSet*, vector<const ItemSet*>, bool (*)(const ItemSet*, const ItemSet*)> Candidates;
	Candidates mCandidates;

	ItemSet* mAcceptedCandidate;

	islist* mSingletonList;
	islist* mItemSetList;

	uint32 mMinSup;
};


#endif // __SLIMPLUS_H
