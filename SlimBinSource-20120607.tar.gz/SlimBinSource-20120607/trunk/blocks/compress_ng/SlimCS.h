//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifndef __SLIMCS_H
#define __SLIMCS_H

#include "../algo/coverpartial/CPOACodeTable.h"

#include "Algo_ng.h"

class Codetable;

struct Candidate {
	uint32 i;
	uint32 j;
	double heuristic;
	double tmp; // we need a temporary value to store the not yet complete gain_ct_ij;
	Candidate(uint32 i, uint32 j, double heuristic, double tmp = 0.0) : i(i), j(j), heuristic(heuristic), tmp(tmp) {};
	friend bool operator< (const Candidate &x, const Candidate &y);
	friend bool operator> (const Candidate &x, const Candidate &y);
	friend bool operator== (const Candidate &x, const Candidate &y);
};

bool operator< (const Candidate &x, const Candidate &y);
bool operator> (const Candidate &x, const Candidate &y);
bool operator== (const Candidate &x, const Candidate &y);

enum slim_est_strategy { SLIM_USAGE, SLIM_GAIN, SLIM_NORMALIZED_GAIN, SLIM_NORMALIZED_GAIN_CT};

class SlimCS: public Algo_ng {

// Slim in cover space

public:

	SlimCS(CodeTable* ct, HashPolicyType hashPolicy, Config* config);
	~SlimCS();

	virtual string	GetShortName();

	virtual CodeTable*	DoeJeDing(const uint64 candidateOffset=0, const uint32 startSup=0);

private:

	void				UpdateLocalCTStuff();
	ItemSet*			NextCandidate(double& heuristic);
	static uint32		CountUsageMatches(uint32* usage_x, uint32 usage_cnt_x, uint32* usage_y, uint32 usage_cnt_y, uint32 minUsage);
	void				ProgressToScreen(const uint64 curCandidate, CodeTable *ct);


	uint32 mMinSup;

	// Local CT stuff
	CPOACodeTable* mFriendlyCT;

	uint32 mCurNumCTElems;
	uint32* mUsageCounts; // Usage count of both code table elements and alphabet
	uint32* mOrigIdx; //
	uint32* mAlphabetIdx; // AlphabetIdx or AlphabetSize, which reflects precense of itemset
	ItemSet** mItemSetIdx; // Pointer to itemset or null
	double* mStdLengths;

	uint32 mCandidate_i;
	uint32 mCandidate_j;
	list<uint32>* mRejectedCandidates; // maybe use array
	vector<Candidate> mTopCandidates;
	bool mMoreCandidates;

	double mScreenReportBits;

	slim_est_strategy mEstStrategy;
	uint32 mNumTopCandidates;

	double mMaxTime;
};


#endif // __SLIMCS_H
