//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifndef __STANDARDCODETABLE_H
#define __STANDARDCODETABLE_H

/*				CT(ST) -- The Standard Codetable				*/
// Note: not a Real CodeTable, as this one is based only on singleton frequencies.

class CodeTable;
class Database;
class ItemSet;

class StandardCodeTable {
public:
	// Create ST with 0-length codes
	StandardCodeTable(uint32 numCounts);

	// Induce ST from given counts
	StandardCodeTable(uint32 *counts, uint32 numCounts);

	// Induce ST from frequencies in given Database
	StandardCodeTable(Database *db);

	~StandardCodeTable();

	/* --- Manipulation --- */
	void AddLaplace();
	void RemoveLaplace();

	/* --- Calculation of (standard) lengths --- */
	double GetCodeLength(uint32 singleton);
	double GetCodeLength(ItemSet *is);
	double GetCodeLength(uint16 *set, uint32 numItems);

	//static? double GetStandardSize(Database *db);

	// Get the usual array
	double* GetStdLengths() { return mCodeLengths; }

protected:
	void	UpdateCodeLengths();

	double	*mCodeLengths;
	uint32	*mCounts;
	uint64	mCountSum;
	uint32	mNumCounts;

	uint32 mLaplace;
};

#endif // __STANDARDCODETABLE_H
