//
// Copyright (c) 2005-2012, Matthijs van Leeuwen, Jilles Vreeken, Koen Smets
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
//
// Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
// Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials // provided with the distribution.
// Neither the name of the Universiteit Utrecht, Universiteit Antwerpen, nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

#ifdef ENABLE_TILES

#include "../global.h"

// qtils
#include <Config.h>
#include <FileUtils.h>
#include <ArrayUtils.h>
#include <StringUtils.h>
#include <RandomUtils.h>
#include <TimeUtils.h>

// bass
#include <Bass.h>
#include <db/Database.h>
#include <itemstructs/CoverSet.h>

#include "../croupier/tiles/TileMiner.h"
#include "../blocks/tile/TilingMiner.h"
#include "../blocks/tile/OverlappingTilingMiner.h"

#include "TileTH.h"

TileTH::TileTH(Config *conf) : TaskHandler(conf){

}
TileTH::~TileTH() {
	// not my Config*
}

void TileTH::HandleTask() {
	string command = mConfig->Read<string>("command");

	if(command.compare("minetiles") == 0)					MineTiles();
	else	if(command.compare("minetiling") == 0)			MineTiling();

	else	throw string(__FUNCTION__) + ": Unable to handle task `" + command + "`";
}

string TileTH::BuildWorkingDir() {
	//char s[100];
	//_i64toa_s(Logger::GetCommandStartTime(), s, 100, 10);
	return mConfig->Read<string>("command") + "/";
}

void TileTH::MineTiles() {
	TileMiner *miner = new TileMiner(mConfig);
	miner->MineTiles();
	delete miner;
}

void TileTH::MineTiling() {
	OverlappingTilingMiner *miner = new OverlappingTilingMiner(mConfig);
	miner->MineTiling();
	delete miner;
}

#endif // ENABLE_TILES
